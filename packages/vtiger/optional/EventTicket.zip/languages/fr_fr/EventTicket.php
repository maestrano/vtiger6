<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$languageStrings = array(
	'EventTicket' => '',
	'SINGLE_EventTicket' => '',
	'LBL_BLOCK_GENERAL_INFORMATION' => '',
	'LBL_BLOCK_SYSTEM_INFORMATION' => '',
	'LBL_TICKET_NUMBER' => '',
	'LBL_TICKET_NAME' => '',
	'LBL_DESCRIPTION' => '',
	'LBL_QUANTITY_TOTAL' => '',
	'LBL_QUANTITY_SOLD' => '',
	'LBL_EVENT_MANAGEMENT' => '',
	'LBL_TICKET_PRICE' => '',
	'CONTACTS' => '',
	'LEADS' => '',

);

?>
